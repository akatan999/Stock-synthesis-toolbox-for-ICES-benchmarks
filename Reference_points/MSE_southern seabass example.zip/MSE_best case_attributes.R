# model_refpts.R - DESC
# 2024_sol.27.4_benchmark_assessment/model_refpts.R

# Copyright (c) WUR, 2024.
# Author: Iago MOSQUEIRA (WMR) <iago.mosqueira@wur.nl>
# Modified by Max Cardinale
# Distributed under the terms of the EUPL-1.2

library(mse)
library(FLRef)
library(r4ss)
library(ss3om)
library(progressr)
handlers(global=TRUE)
library(doFuture)
library(icesTAF)

# Windows
plan(multisession, workers=5)

# Linux, OSX
plan(multicore, workers=5)

# DIMS
its <- 10
fy <- 2083
iy= 2024

#Load the model and SR parameters
out <- SS_output(dir="~/Max/Commitees/ICES/WKBBASS/Southern stock/Basecase",covar=T)

R0 <- exp(out$parameters$Value[out$parameters$Label=="SR_LN(R0)"])
s <- out$parameters$Value[out$parameters$Label=="SR_BH_steep"]
sigmaR <- out$parameters$Value[out$parameters$Label=="SR_sigmaR"]
rho <- out$parameters$Value[out$parameters$Label=="SR_autocorr"]
B0 <- out$derived_quants$Value[out$derived_quants$Label=="SSB_unfished"]
SSBcv <- out$derived_quants$StdDev[out$derived_quants$Label=="SSB_2023"]/out$derived_quants$Value[out$derived_quants$Label=="SSB_2023"]
Fcv <- out$derived_quants$StdDev[out$derived_quants$Label=="F_2023"]/out$derived_quants$Value[out$derived_quants$Label=="F_2023"]
BMSYss <- out$derived_quants$Value[out$derived_quants$Label=="SSB_MSY"]
FMSYss <- out$derived_quants$Value[out$derived_quants$Label=="annF_MSY"]
MSYss <- out$derived_quants$Value[out$derived_quants$Label=="Dead_Catch_MSY"]
TBOss <-  out$derived_quants$Value[out$derived_quants$Label=="Totbio_unfished"]

stk <- readFLSss3(dir="~/Max/Commitees/ICES/WKBBASS/Southern stock/Basecase",wtatage = FALSE)

#Set the fbar range
range(stk)[["minfbar"]] <- 4
range(stk)[["maxfbar"]] <- 15

###Set units
stock(stk) <- computeStock(stk)
units(catch(stk)) <- "t"
units(catch.n(stk)) <- "1000"
units(catch.wt(stk)) <- "kg"
units(discards(stk)) <- "t"
units(discards.n(stk)) <- "1000"
units(discards.wt(stk)) <- "kg"
units(landings(stk)) <- "t"
units(landings.n(stk)) <- "1000"
units(landings.wt(stk)) <- "kg"
units(stock(stk)) <- "t"
units(stock.n(stk)) <- "1000"
units(stock.wt(stk)) <- "kg"
units(m(stk)) <- "m"
units(mat(stk)) <- ""
units(harvest(stk)) <- "f"
units(harvest.spwn(stk)) <- ""
units(m.spwn(stk)) <- ""

#stk@discards.n[] = 0.001
#stk@discards.wt[] = stock.wt(rstk)
#stk@discards[] = 1e-04

# set some other slots so that SSB can be calculated (M is approximate as the weight are not estimated exactly at the spawning time)
m.spwn(stk)[] <- 0
harvest.spwn(stk)[] <- 0
plot(stk)

###If you want to cut the time series
#stk <- window(stk, start=2000,end=2023)

# -- OM conditioning

# COERCE FLSR as bevholt(a,b) from SS
nsr <- ab(fmle(as.FLSR(stk, model='bevholtSV'),
  fixed=list(s=s, v=B0,
  spr0=B0/R0)))

##Fitting and plotting the SR data
#nsr1 <- FLSR(ssb=ssb(stk), rec=rec(stk),model='bevholtSV')
#nsr1.mle <- fmle(nsr1)
#plot(nsr1.mle)

# FIT brps as single to hack Blim
brp_single <- brp(FLBRP(stk, sr=nsr))
brps_single <- remap(refpts(brp_single), R0=c('virgin', 'rec'), MSY=c('msy', 'yield'))

#Use SS reference points (optional)
brps_single$FMSY = FMSYss
brps_single$SBMSY = BMSYss
brps_single$B0 = TBOss
brps_single$SB0 = B0
brps_single$MSY = MSYss
brps_single$R0 = R0

##Deterministic RPs from FLR
#brp_FLR = computeFbrp(stk,nsr, proxy="sprx",x=50,blim=0.15)

# ADD other reference points (works for best case scenario, needs to be modified for ensemble or several OMs) trigger and target will be estimated later by the grid but a value is needed here also, which is not affecting the following calculations; Blim set at 15% B0 as example
brps_single$Blim <- B0*0.15 
trigger = BMSYss
target = FMSYss

save(brps_single, brp_single, trigger, target, file="Southerseabass_attributes.rda", compress="xz")

