###########
library(ss3om)
library(r4ss)
setwd("~/Max/Commitees/ICES/WKBBASS/Southern stock/")

path <- "~/Max/Commitees/ICES/WKBBASS/Southern stock/Basecase"

# LOAD output
out <- SS_output(path, covar=TRUE)

# FLR
stk <- readFLSss3(path)
rps <- readFLRPss3(path)
srr <- readFLSRss3(path)

#Set the fbar range
range(stk)[["minfbar"]] <- 4
range(stk)[["maxfbar"]] <- 15

##Load the retro
retro <- lapply(setNames(file.path(path, "Retrospective",
                                   paste("retro",0:-5,sep="")), paste("retro",0:-5,sep="")),readFLSss3)

retro <- FLStocks(Map(function(x, y)
  window(x, end=y), x=retro, y=seq(2023, 2018)))

#Change to unexploited spawning biomass
B0 <- out$derived_quants$Value[out$derived_quants$Label=="SSB_unfished"]
rps[[1]] <- B0

#Set the stock name
stk@name = "Southern seabass"

# set some other slots so that SSB can be calculated (M is approximate as the weight are not estimated exactly at the spawning time)
m.spwn(stk)[] <- 0
harvest.spwn(stk)[] <- 0

# FUNCTIONS {{{
getabSR <- function(stk, srr) {
  ab(fmle(as.FLSR(stk, model='bevholtSV'),
          fixed=list(s=params(srr)$s, v=params(srr)$v,
                     spr0=params(srr)$v/params(srr)$R0)))
}

# FIT brps
nsr <- getabSR(stk, srr)
brp <- brp(FLBRP(stk, sr=nsr))

# SAVE
save(out, brp, stk, srr, rps, retro,
     file="Reference_run.rda", compress='xz')
##########################################################

