library(r4ss)
library(ggplot2)
#devtools::install_github("r4ss/r4ss")
#devtools::install_github("r4ss/r4ss", ref="development")
#remotes::install_github('r4ss/r4ss', ref = 'SSplotPars')

###Working directory

out <- SS_output(dir="~/Max/Commitees/ICES/WKBSS3/Stock assessments/Black bellied anglerfish/Basecase",covar=T)

SS_plots(out,uncertainty=T,png=T,forecastplot=TRUE, fitrange = TRUE, parrows=5, parcols=4, showdev= FALSE) ##png allows you to save them as png files in a dedicated folder or use pdf (,pdf=T)

SS_decision_table_stuff(retroModels, yrs = 2021:2022)

save(ss3rep, file="ss3rep.Rdata")
