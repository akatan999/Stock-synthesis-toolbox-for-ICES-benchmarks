
library(r4ss)
r4ss::SS_output

ss3rep = readRDS(file.path("rdata", stock.file))

forecast.dir = file.path(model, "forecast")

dir.create(forecast.dir, showWarnings = F)

fmsydir = file.path(forecast.dir, "Fmsy")

dat = "sbr_dat.ss"
ctl = "sbr_ctl.ss"
ss.exe = "ss3.exe"

SSnewrun(model = file.path(model), dat = dat, ctl = ctl, newdir = fmsydir,
         ss.exe = "ss3.exe")

fc <- SS_readforecast(file.path(fmsydir, "forecast.ss"), verbose = F)

Fexp = ss3rep$exploitation

Fexp$Fapic = apply(as.matrix(ss3rep$exploitation[, -c(1:6)]),
                   1, sum, na.rm = T)

Fapic = aggregate(Fapic ~ Yr, Fexp, mean)

Fbar = aggregate(annual_F ~ Yr, Fexp, mean)

endyr = ss3rep$endyr
if (fc$Bmark_years[3] < -90) {
  nfc = length(min(ss3rep$exploitation$Yr + 1):endyr) # excluded init year
} else {
  # if specified (e.g. -2, 0)
  nfc = fc$Bmark_years[4] - fc$Bmark_years[3] + 1
}
# Benchmark reference years
bmyrs = (endyr - nfc + 1):endyr
bmyrs

Fratio = mean(Fapic$Fapic[Fapic$Yr %in% max(bmyrs)]/Fbar$annual_F[Fbar$Yr %in%
                                                                    max(bmyrs)])
Fratio

Fmsy = bms["Fmsy"][[1]]

Fmsy.apic = Fmsy * Fratio
Fmsy # Fbar

Fmsy.apic

nseas = length(unique(ss3rep$exploitation$Seas)) # number of seasons
fleets = unique(ss3rep$fatage$Fleet) # fleets
nfleets = length(fleets) #

# subset to benchmark years for selectivity
fexp = ss3rep$exploitation[ss3rep$exploitation$Yr %in% bmyrs,
]
fexp = cbind(fexp[, 1:2], fexp[, -c(1:5)])[, -3] #><> single fleet trick
# flip
fexp = reshape2::melt(fexp, id.vars = c("Yr", "Seas"), variable.name = "Fleet",
                      value.name = "Fapic")
tail(fexp)

fleet = data.frame(Fleet = ss3rep$FleetNames, ID = ss3rep$fleet_ID)
fexp$Fleet = fleet[match(fexp$Fleet, fleet$Fleet), 2]

Fap = aggregate(Fapic ~ Seas + Fleet, fexp, mean)
Fap$prop = Fap$Fapic/sum(Fap$Fapic) * nseas
Fap

# F status q
nfsq = 1
nint = 1

fsq = ss3rep$exploitation[ss3rep$exploitation$Yr %in% ((endyr -
                                                          nfsq + 1):endyr), ]
fsq = cbind(fsq[, 1:2], fsq[, -c(1:5)])[, -3] #><> single fleet trick
fsq = reshape2::melt(fsq, id.vars = c("Yr", "Seas"), variable.name = "Fleet",
                     value.name = "Fapic")
Fsq = aggregate(Fapic ~ Seas + Fleet, fsq, mean)

fc$Nforecastyrs = 3
nfyrs = fc$Nforecastyrs
fyrs = endyr + c(1:nfyrs)

fvec = c(rep(Fsq$Fapic, nint), rep(Fmsy * Fratio * Fap$prop,
                                   nfyrs - nint))

fc$ForeCatch = data.frame(Year = rep(fyrs, each = nseas * nfleets),
                          Seas = 1:nseas, Fleet = rep(fleets, each = nseas), catch_or_F = fvec,
                          Basis = 99)
tail(fc$ForeCatch, 9)

ss3rep$catch[ss3rep$catch$Yr %in% tail(years, 4), ]

Cexp = ss3rep$catch[ss3rep$catch$Yr %in% bmyrs, ]

Cap = aggregate(Exp ~ Seas + Fleet, Cexp, mean)
Cap$prop = Cap$Exp/sum(Cap$Exp) * nseas
Cap

fc$ForeCatch[fc$ForeCatch$Year == 2023, "catch_or_F"] = TAC *
  Cap$prop
fc$ForeCatch[fc$ForeCatch$Year == 2023, "Basis"] = 2
fc$ForeCatch

fc$eof = TRUE
fc$InputBasis = -1

SS_writeforecast(fc, file = file.path(fmsydir, "forecast.ss"),
                 overwrite = T, verbose = F)




